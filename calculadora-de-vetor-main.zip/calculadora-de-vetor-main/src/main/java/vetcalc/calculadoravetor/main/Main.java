package vetcalc.calculadoravetor.main;

import vetcalc.calculadoravetor.HelloApplication;

/**
 * @author Murilo Nunes <murilo_no@outlook.com>
 * @date 31/10/2024
 * @brief Class Main
 */
public class Main {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
